import React, { useState, useEffect } from "react";

export default function App() {
  const correctUsername = "Raushan";
  const correctPassword = "Raushan";

  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  const [task, setTask] = useState("");
  const [subject, setSubject] = useState("Physics");
  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem("jeeTasks");
    return saved ? JSON.parse(saved) : [];
  });

  const [goal, setGoal] = useState(10);

  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    localStorage.setItem("jeeTasks", JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    let interval = null;

    if (running) {
      interval = setInterval(() => {
        if (seconds > 0) {
          setSeconds(seconds - 1);
        }

        if (seconds === 0) {
          if (minutes === 0) {
            clearInterval(interval);
            setRunning(false);

            const audio = new Audio(
              "https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg"
            );

            audio.play();
            alert("⏰ Study Session Complete");
          } else {
            setMinutes(minutes - 1);
            setSeconds(59);
          }
        }
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [running, seconds, minutes]);

  const handleLogin = () => {
    if (
      username === correctUsername &&
      password === correctPassword
    ) {
      setLoggedIn(true);
      setLoginError("");
    } else {
      setLoginError("Wrong Username or Password");
    }
  };

  const addTask = () => {
    if (!task) return;

    const newTask = {
      id: Date.now(),
      text: task,
      subject,
      done: false,
    };

    setTasks([newTask, ...tasks]);
    setTask("");
  };

  const toggleTask = (id) => {
    setTasks(
      tasks.map((t) =>
        t.id === id ? { ...t, done: !t.done } : t
      )
    );
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((t) => t.id !== id));
  };

  const pending = tasks.filter((t) => !t.done);
  const completed = tasks.filter((t) => t.done);

  const streak = completed.length;

  if (!loggedIn) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "linear-gradient(to right,#0f172a,#1e293b)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          fontFamily: "Arial",
        }}
      >
        <div
          style={{
            background: "#111827",
            color: "white",
            width: "380px",
            padding: "40px",
            borderRadius: "25px",
            boxShadow: "0 0 30px rgba(0,0,0,0.5)",
          }}
        >
          <h1
            style={{
              textAlign: "center",
              fontSize: "35px",
            }}
          >
            🚀 JEE Tracker
          </h1>

          <p
            style={{
              textAlign: "center",
              color: "#9ca3af",
            }}
          >
            Professional Study Dashboard
          </p>

          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={{
              width: "100%",
              padding: "14px",
              marginTop: "25px",
              borderRadius: "12px",
              border: "none",
              background: "#1f2937",
              color: "white",
              fontSize: "16px",
            }}
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              width: "100%",
              padding: "14px",
              marginTop: "15px",
              borderRadius: "12px",
              border: "none",
              background: "#1f2937",
              color: "white",
              fontSize: "16px",
            }}
          />

          {loginError && (
            <p style={{ color: "red", marginTop: "10px" }}>
              {loginError}
            </p>
          )}

          <button
            onClick={handleLogin}
            style={{
              width: "100%",
              padding: "14px",
              marginTop: "20px",
              background: "#2563eb",
              color: "white",
              border: "none",
              borderRadius: "12px",
              fontSize: "17px",
              cursor: "pointer",
            }}
          >
            Login
          </button>

          <p
            style={{
              marginTop: "20px",
              textAlign: "center",
              color: "#9ca3af",
            }}
          >
            Username: Raushan
            <br />
            Password: Raushan
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#0f172a",
        color: "white",
        padding: "20px",
        fontFamily: "Arial",
      }}
    >
      <h1
        style={{
          textAlign: "center",
          fontSize: "40px",
        }}
      >
        🚀 JEE Study Dashboard
      </h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))",
          gap: "20px",
          marginTop: "30px",
        }}
      >
        <div style={cardStyle}>
          <h2>🔥 Streak</h2>
          <h1>{streak}</h1>
        </div>

        <div style={cardStyle}>
          <h2>📚 Tasks</h2>
          <h1>{tasks.length}</h1>
        </div>

        <div style={cardStyle}>
          <h2>⏳ Pending</h2>
          <h1>{pending.length}</h1>
        </div>

        <div style={cardStyle}>
          <h2>✅ Completed</h2>
          <h1>{completed.length}</h1>
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "20px",
          marginTop: "30px",
        }}
      >
        <div style={panelStyle}>
          <h2>🎯 Add Daily Target</h2>

          <input
            value={task}
            onChange={(e) => setTask(e.target.value)}
            placeholder="Enter today's target"
            style={inputStyle}
          />

          <select
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            style={inputStyle}
          >
            <option>Physics</option>
            <option>Chemistry</option>
            <option>Maths</option>
          </select>

          <button onClick={addTask} style={buttonStyle}>
            ➕ Add Target
          </button>
        </div>

        <div style={panelStyle}>
          <h2>⏰ Study Timer</h2>

          <div
            style={{
              fontSize: "60px",
              textAlign: "center",
              marginTop: "20px",
            }}
          >
            {minutes}:{seconds < 10 ? `0${seconds}` : seconds}
          </div>

          <input
            type="number"
            value={minutes}
            onChange={(e) => setMinutes(Number(e.target.value))}
            style={inputStyle}
          />

          <div style={{ marginTop: "15px" }}>
            <button
              onClick={() => setRunning(true)}
              style={greenButton}
            >
              ▶ Start
            </button>

            <button
              onClick={() => setRunning(false)}
              style={redButton}
            >
              ⏹ Stop
            </button>
          </div>
        </div>
      </div>

      <div style={panelStyle2}>
        <h2>🔥 Daily Goal Progress</h2>

        <input
          type="number"
          value={goal}
          onChange={(e) => setGoal(e.target.value)}
          style={inputStyle}
        />

        <h3>
          {completed.length}/{goal} Completed
        </h3>

        <progress
          value={completed.length}
          max={goal}
          style={{ width: "100%", height: "30px" }}
        ></progress>
      </div>

      <div style={panelStyle2}>
        <h2>📚 Task Manager</h2>

        {tasks.length === 0 && (
          <p>No tasks added yet.</p>
        )}

        {tasks.map((t) => (
          <div
            key={t.id}
            style={{
              background: "#1e293b",
              padding: "15px",
              borderRadius: "12px",
              marginTop: "10px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <div>
              <input
                type="checkbox"
                checked={t.done}
                onChange={() => toggleTask(t.id)}
              />

              <span
                style={{
                  marginLeft: "10px",
                  textDecoration: t.done
                    ? "line-through"
                    : "none",
                }}
              >
                {t.text} ({t.subject})
              </span>
            </div>

            <button
              onClick={() => deleteTask(t.id)}
              style={{
                background: "red",
                color: "white",
                border: "none",
                padding: "8px 15px",
                borderRadius: "10px",
              }}
            >
              Delete
            </button>
          </div>
        ))}
      </div>

      <div
        style={{
          background: "#1e293b",
          padding: "20px",
          borderRadius: "20px",
          marginTop: "30px",
        }}
      >
        <h2>🔔 Reminder</h2>
        <p>
          You still have {pending.length} pending tasks.
        </p>
      </div>
    </div>
  );
}

const cardStyle = {
  background: "#1e293b",
  padding: "20px",
  borderRadius: "20px",
  textAlign: "center",
};

const panelStyle = {
  background: "#111827",
  padding: "20px",
  borderRadius: "20px",
};

const panelStyle2 = {
  background: "#111827",
  padding: "20px",
  borderRadius: "20px",
  marginTop: "30px",
};

const inputStyle = {
  width: "100%",
  padding: "14px",
  marginTop: "15px",
  borderRadius: "12px",
  border: "none",
  background: "#1e293b",
  color: "white",
  fontSize: "16px",
};

const buttonStyle = {
  width: "100%",
  padding: "14px",
  marginTop: "15px",
  background: "#2563eb",
  color: "white",
  border: "none",
  borderRadius: "12px",
  fontSize: "16px",
};

const greenButton = {
  background: "green",
  color: "white",
  border: "none",
  padding: "12px 20px",
  borderRadius: "10px",
  marginRight: "10px",
};

const redButton = {
  background: "red",
  color: "white",
  border: "none",
  padding: "12px 20px",
  borderRadius: "10px",
};